if test -e //mnt/product/persist-lg/rct/rct.cfg
then
	rm -rf //mnt/product/persist-lg/rct/rct.cfg
fi