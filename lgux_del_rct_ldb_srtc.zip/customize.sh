#SKIPUNZIP=1
#chmod 777 ${0%/*}/backup/backup.sh
#${0%/*}/backup/backup.sh
device_info=$(getprop ro.product.system.brand)
system_ver=$(getprop ro.build.version.sdk)
#echo $system_ver
if [ "$device_info"="lge" ] || [ $device_info=="lg" ]
then
	if [ "$system_ver"=="31" ] || [ "$system_ver"=="30" ]
	then
		echo "正在备份..."
		mkdir -p /data/adb/modules/lgux_del_rct_ldb_srtc/backup
		cp //mnt/product/persist-lg/rct/rct.cfg /data/adb/modules/lgux_del_rct_ldb_srtc/backup
		if test -e /data/adb/modules/lgux_del_rct_ldb_srtc/backup/rct.cfg
		then
			echo "备份成功！"
			echo "正在删除RCT、LDB、SRTC..."
			rm -rf //mnt/product/persist-lg/rct/rct.cfg
			if test -e //mnt/product/persist-lg/rct/rct.cfg
			then
				rm -rf /data/adb/modules/lgux_del_rct_ldb_srtc
				abort "删除失败...请稍后再试。安装已停止，所有操作已被撤销。"
			else 
				echo -e "已完成！重启后生效。\n位于mnt/product/persist-lg/rct/rct.cfg的文件\n已被备份至模块工作目录的backup文件夹下，原文件已被删除。\n当模块卸载后所有文件都会恢复。玩机愉快awa！"
			fi
		else
			rm -rf /data/adb/modules/lgux_del_rct_ldb_srtc
			abort "备份失败...请稍候再试。安装已停止，所有操作已被撤销。"
		fi
	else
		abort "系统的安卓版本不为安卓12！安装已停止，所有操作已被撤销。"
	fi
else
	abort "你用的真的是LG手机&LGUX系统吗？安装已停止，所有操作已被撤销。"
fi